
<?php session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom']; 
  $fnc = $_SESSION['fnc'];
}else{
        echo '<script language="Javascript">';
        echo 'document.location.replace("./logout.php")'; // -->
        echo ' </script>';
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>Users</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <link rel="stylesheet" type="text/css" href="styles.css">
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <!--bootstrap-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="crossorigin="anonymous"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    

  <!--Font awasome-->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="wrapper ">
 

 <!-- Administrateur sidebar -->
  <?php
          if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
          ?>



    <!-- Operateur sidebar --> 
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
        <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <center>
          <button class="nav-item active btn mt-3">Tableau de bord</button>
        </center>
        <ul class="p-2 m-2 rounded" id="sidebarLink">
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Enregistrement</h5>
          <li><a href="acc.php">Ajouter un danger</a></li>
          <li><a href="lieu.php">Ajouter un lieu</a></li>
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-4 fas fa-list-alt"></i>Listage</h5>
          <li><a href="register.php">Liste</a></li>
        </ul>
      </div>
    </div>




              <?php
            } else {
                ?> 


<!-- Superviseur sidebar -->




     <?php }?>
  
      <!-- Navbar -->
      <nav class="navbar navbar-light p-0 mb-0 " id="navbar">
        <a class="" href="#">
          <img src="danger.png" width="150" height="auto" class="d-inline-block align-top img-fluid" alt="logo" style="margin-left: 250px;">
        </a>

        <ul class="navbar mr-5" style="list-style: none; font-size: 25px;">
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-bell"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-envelope"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"> <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a> </li>
        </ul>

      </nav>
      <!-- End Navbar -->
      <div class="content"style="margin-left: 250px;">
        <div class="container-fluid" >
          <!-- your content here -->

            <?php
                  if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
                  ?>
            <!-- Administrateur -->





        <!---Fin administrateur -->





            
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
            <!-- Opérateur -->

            <div class="col ">
              <div class=" color1 rounded-0 pt-0 ">
                  <div class="row">
                    <div class="col color2 mt-3 rounded d-flex justify-content-center bg-dark">
                      <h1 style="color: #FFF;">Contenu</h1>
                    </div>
                  </div>
                  <div class="container">
                    <div class="row justify-content-center align-items-center ">
                      <div class="col-6 card card-body mt-4 shadow bg-info ">
                        <h2 class="mb-4">Modifier une information</h2>

        <!-- Formulaire d'enregistrement infos -->

                      <?php

                          if (isset($_POST['savedanger'])) {?>
                            
                          <div class="alert alert-success alert-dismissible fade show" role="alert">
                            Enregistré avec succes !
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>

                      <?php }?>

                      <!-- alerte -->

                      <?php

                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "dangerviewdb";

                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                      
                      if(isset($_POST['edit_btn']))
                      {
                            $id = $_POST['edit_id'];
                        
                            $query = "SELECT * FROM dangertable WHERE id= '$id' ";
                        
                            $query_run = mysqli_query($conn, $query); 

                            foreach($query_run as $row){ ?>
        

                      <form action="code.php" method="POST">
 
                            <input type="hidden" name="id_edit" value="<?php echo $row['id'] ?>">
                            <div class="form-group">
                            <label class="text-dark" for="formGroupExampleInput">Type de danger</label>
                            <input type="text" value="<?php echo $row['type'] ?>" name="type_edit" id="formGroupExampleInput" class="form-control" autofocus requierd>
                            </div>
                            <div class="form-group">
                            <label class="text-dark" for="exampleFormControlSelect1">Victime</label>
                            <select class="form-control" value="<?php echo $row['victime'] ?>"  name="victime_edit" id="exampleFormControlSelect1">
                                <option>Homme</option>
                                <option>Femme</option>
                                <option>Enfant</option>
                                <option>Groupe de personnes</option>
                                <option>Nature</option>
                            </select>
                            </div>
                            <div class="form-group">
                            <label class="text-dark" for="exampleFormControlSelect2">Bourreau</label>
                            <select class="form-control" value="<?php echo $row['bourreau'] ?>"  name="bourreau_edit" id="exampleFormControlSelect2" required>
                                <option>Homme</option>
                                <option>Femme</option>
                                <option>Enfant</option>
                                <option>Groupe de personnes</option>
                                <option>Nature</option>
                            </select>
                            </div>
                            <div class="form-group">
                            <label class="text-dark" for="formGroupExampleInput2">Lieu</label>
                            <input type="text" class="form-control" value="<?php echo $row['lieu'] ?>" id="formGroupExampleInput2" name="lieu_edit" placeholder="Ajouter un lieu">
                            </div>
                            <div class="form-group">
                            <label class="text-dark" for="formGroupExampleInput2">Source</label>
                            <input type="text" class="form-control" value="<?php echo $row['source'] ?>" id="formGroupExampleInput2" name="source_edit" placeholder="Ajouter une source">
                            </div>
                            <div class="form-group">
                            <label class="text-dark" >Description</label>
                            <textarea rows="2" class="form-control" value="<?php echo $row['description'] ?>" name="description_edit" placeholder="Entrer une description du danger"></textarea>
                            </div>
                            <button class="btn btn-danger mt-3" value="Modifier"><a href="register.php"></a>ANNULER</button>
                            <input type="submit" name="update" class="btn btn-primary mt-3" value="Modifier">
                      </form> 

                      <?php



                            }
                        

                      }
                      ?>

            <!-- fin de formulaire  --> 
                      </div>
                  </div>  
                </div>
              </div>
          </div>




            <?php
          } else {
              ?> 




            <p>Superviseur</p>




         <?php }?>




            </div>
          </div>
          <footer class="footer">
            <div class="container-fluid">
              <nav class="float-left" style="margin-left:250px;">
                <ul>
                  <li>
                    <a href="">
                       DANGER VIEW ENGINE
                    </a>
                  </li>
                </ul>
              </nav>
              <div class="copyright float-right" >
                Copright
                &copy;
                <script>
                  document.write(new Date().getFullYear())
                </script>, 
              </div>
              <!-- your footer here -->
            </div>
          </footer>
        </div>
      </div>

      <?php


      ?>

      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    </body>

</html>




















