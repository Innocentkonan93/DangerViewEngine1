<?php session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom']; 
  $fnc = $_SESSION['fnc'];
}else{
        echo '<script language="Javascript">';
        echo 'document.location.replace("./logout.php")'; // -->
        echo ' </script>';
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>Users</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <!--bootstrap-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <!--Font awasome-->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="wrapper ">
 

 <!-- Administrateur sidebar -->
  <?php
          if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
          ?>

    <div class="sidebar" data-color="green" data-background-color="white">
    <!--Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag-->
    <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
        <img src="avatar.png">
      </a>
      <h3 href="" class="simple-text logo-normal">
        <?php echo "$nom"; ?>
      <h3>
      <h5 class="text-center"><?php echo "$fnc"; ?></h5>
    </div>
    <div class="sidebar-wrapper ">
      <ul class="nav">
        <li class="nav-item active  ">
          <a class="nav-link" href="#0">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
          </a>
        </li>

        <ul class="list-group mt-5 ">
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
        <!-- your sidebar here -->
      </ul>
    </div>
  </div>

    <!-- Operateur sidebar --> 
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
       <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          </li>
          <ul class="list-group mt-5 ">
            <h6 class="text-center" >Enregistrement</h6>
            <li class="list-group-item pl-2"> <a href="page.php"><i class=" fa fa-plus-circle"></i>Enregistrer un danger</a> </li>
            <li class="list-group-item pl-2"> <a href="lieu.php"><i class=" fa fa-plus-circle"></i>Ajouter un lieu</a> </li>
          </ul>
          <ul class="list-group mt-4 ">
            <h6 class="text-center">Modification/Suppression</h6>
            <li class="list-group-item pl-2"> <a href="register.php"><i class="fas fa-tools"></i>Modifier un danger</a> </li>
          </ul>
      </div>
    </div>




              <?php
            } else {
                ?> 


<!-- Superviseur sidebar -->


  <div class="sidebar" data-color="green" data-background-color="white">
      <div class="logo">
         <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <ul class="list-group mt-5 ">
            <li class="list-group-item">Josco</li>
            <li class="list-group-item">Josco</li>
            <li class="list-group-item">Josco</li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>





     <?php }?>
  
      <!-- Navbar -->
      <nav class="navbar navbar-light p-0 bg-info mb-0 ">
        <a class="" href="#">
          <img src="danger.png" width="150" height="auto" class="d-inline-block align-top img-fluid" alt="logo" style="margin-left: 250px;">
        </a>

        <ul class="navbar mr-5" style="list-style: none; font-size: 25px;">
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-bell"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-envelope"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"> <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a> </li>
        </ul>

      </nav>
      <!-- End Navbar -->
      <div class="content"style="margin-left: 250px3;>
        <div class="container-fluid">
          <!-- your content here -->

            <?php
                  if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
                  ?>

                  <p>Administrateur</p>
                    
                    <?php
                  }elseif($fnc!= 'Superviseur'){
                  ?>
                      
                    <!-- Opérateur -->

                    <div class="col ">
                      <div class="jumbotron color1 rounded-0 pt-0 ">
                          <div class="row">
                            <div class="col color2 mt-3 rounded d-flex justify-content-center bg-dark">
                              <h1 style="color: #FFF;">Contenu</h1>
                            </div>
                          </div>
                          <div class="container">
                            <div class="row justify-content-center align-items-center ">
                              <div class="col-6 card card-body mt-4 shadow bg-warning ">
                                <h2 class="mb-4">Ajouter une information</h2>

                <!-- Formulaire d'enregistrement infos -->

                              <?php

                                  if (isset($_POST['savedanger'])) {?>
                                    
                                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    Enregistré avec succes !
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>

                              <?php }?>

                              <!-- alerte -->

                           



                              <form action="" method="POST">
                                <div class="form-group">
                                  <label class="text-dark" for="formGroupExampleInput">Type de danger</label>
                                  <input type="text" value="<?php echo $row['type']; ?>" name="type" id="formGroupExampleInput" class="form-control">
                                </div>
                                <div class="form-group">
                                  <label class="text-dark" for="exampleFormControlSelect1">Victime</label>
                                  <select class="form-control" value="<?php echo $row['victime'] ?>" name="victime" id="exampleFormControlSelect1">
                                    <option>Homme</option>
                                    <option>Femme</option>
                                    <option>Enfant</option>
                                    <option>Groupe de personnes</option>
                                    <option>Nature</option>
                                  </select>
                                </div>
                                <div class="form-group">
                                  <label class="text-dark" for="exampleFormControlSelect2">Bourreau</label>
                                  <select class="form-control" value="<?php echo $row['bourreau'] ?>" name="bourreau" id="exampleFormControlSelect2" required>
                                    <option>Homme</option>
                                    <option>Femme</option>
                                    <option>Enfant</option>
                                    <option>Groupe de personnes</option>
                                    <option>Nature</option>
                                  </select>
                                </div>
                                <div class="form-group">
                                  <label class="text-dark" for="formGroupExampleInput2">Lieu</label>
                                  <input type="text" class="form-control" id="formGroupExampleInput2" value="<?php echo $row['lieu']; ?>" name="lieu" placeholder="Ajouter un lieu">
                                </div>
                                <div class="form-group">
                                  <label class="text-dark" for="formGroupExampleInput2">Source</label>
                                  <input type="text" class="form-control" id="formGroupExampleInput2" value="<?php echo $row['source']; ?>" name="source" placeholder="Ajouter une source">
                                </div>
                                <div class="form-group">
                                  <label class="text-dark" >Description</label>
                                  <textarea rows="2" class="form-control" value="<?php echo $row['description']; ?>" name="description" placeholder="Entrer une description du danger"></textarea>
                                </div>
                                <input type="submit" name="update" class="btn btn-success mt-3" value="Enregistrer">
                              </form> 
                    <!-- fin de formulaire  --> 
                              </div>
                          </div>  
                        </div>
                      </div>
                  </div>




                      <?php
                    } else {
                        ?> 




                      <p>Superviseur</p>




             <?php }?>




            </div>
          </div>
          <footer class="footer">
            <div class="container-fluid">
              <nav class="float-left" style="margin-left:250px;">
                <ul>
                  <li>
                    <a href="https://www.creative-tim.com">
                       DANGER VIEW ENGINE
                    </a>
                  </li>
                </ul>
              </nav>
              <div class="copyright float-right">
                Copright
                &copy;
                <script>
                  document.write(new Date().getFullYear())
                </script>, 
              </div>
              <!-- your footer here -->
            </div>
          </footer>
        </div>
      </div>
            

      <?php


      ?>

      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    </body>

</html>





<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dangerviewdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}





 //  activités



  if(isset($_POST['delete_btn'])){
  $suppinfo = 'suppinfo';
  
  $sql = "INSERT INTO activites (suppinfo)
  VALUES ('$suppinfo')";
  
  if (mysqli_query($conn, $sql)) {
    echo "Un utilisateur a été enregistré";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  
  }else{
    echo "saisir les informations de l'utilisateur";
  }
  




mysqli_close($conn);

?>


















