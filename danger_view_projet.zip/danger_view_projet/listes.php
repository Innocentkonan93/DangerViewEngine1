<?php session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom']; 
  $fnc = $_SESSION['fnc'];
}else{
        echo '<script language="Javascript">';
        echo 'document.location.replace("./logout.php")'; // -->
        echo ' </script>';
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>Users</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <link rel="stylesheet" type="text/css" href="styles.css">
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <!--bootstrap-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <!--Font awasome-->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <!--jQuery-->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
</head>

<body>
  <div class="wrapper ">
 

 <!-- Administrateur sidebar -->
  <?php
          if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
          ?>

    <div class="sidebar" data-color="green" data-background-color="white">
    <!--Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag-->
    <div class="logo">
    <a href="page.php" class="simple-text logo-mini">
        <img src="avatar.png">
      </a>
      <h3 href="" class="simple-text logo-normal">
        <?php echo "$nom"; ?>
      <h3>
      <h5 class="text-center"><?php echo "$fnc"; ?></h5>
    </div>
    <div class="sidebar-wrapper ">
        <center>
          <button class="nav-item active btn mt-3"><a href="page.php">Tableau de bord</a></button>
        </center>
        <ul class="p-2 m-2 rounded" id="sidebarLink">
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Enregistrement</h5>
          <li><a href="users-save.php">Ajouter un utilisateur</a></li>
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Gestion</h5>
          <li><a href="users_lists.php">Modifier un utilisateur</a></li>
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Listage</h5>
          <li id="active"><a href="listes.php">Voir les listes</a></li>
    </div>
  </div>

    <!-- Operateur sidebar --> 
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <center>
          <button class="nav-item active btn mt-3">Tableau de bord</button>
        </center>
        <ul class="p-2 m-2 rounded" id="sidebarLink">
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Enregistrement</h5>
          <li><a href="acc.php">Ajouter un danger</a></li>
          <li><a href="lieu.php">Ajouter un lieu</a></li>
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-4 fas fa-list-alt"></i>Listage</h5>
          <li><a href="register.php">Liste</a></li>
        </ul>
      </div>
    </div>




              <?php
            } else {
                ?> 


<!-- Superviseur sidebar -->


  <div class="sidebar" data-color="green" data-background-color="white">
      <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <center>
          <button class="nav-item active btn mt-3">Tableau de bord</button>
        </center>
        <ul class="p-2 m-2 rounded" id="sidebarLink">
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Affichage</h5>
          <li><a href="users_lists.php">Utilisateurs</a></li>
          <li><a href="register.php">Dangers enregistrés</a></li>
          <li><a href="activites.php">Activités</a></li>
          <li><a href="messages.php">Message</a></li>
          <li id="active"><a href="listes.php">Tout afficher</a></li>
        </ul>
      </div>
    </div>





     <?php }?>
  
      <!-- Navbar -->
      <nav class="navbar navbar-light p-0  mb-0 " id="navbar">
        <a class="" href="#">
          <img src="danger.png" width="150" height="auto" class="d-inline-block align-top img-fluid" alt="logo" style="margin-left: 250px;">
        </a>

        <ul class="navbar mr-5" style="list-style: none; font-size: 25px;">
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-bell"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-envelope"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"> <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a> </li>
        </ul>

      </nav>
      <!-- End Navbar -->
      <div class="content" style="margin-left: 250px;">
        <div class="container-fluid">
          <!-- your content here -->

            <?php

                  if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
                  ?>

                  <!-- ADMINISTRATEUR -->

                <div class="container">
                  <div class="col color2 mt-3 mb-5 rounded d-flex justify-content-center bg-dark">
                    <h1 style="color: #FFF;">Listes</h1>
                  </div>

                        <!-- alerte -->
                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Dangers enregistrés</h2>                     
                    <table class="table rounded table-info " id="maTable">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Danger</th>
                          <th >Victime</th>
                          <th >Bourreau</th>
                          <th >Lieu</th>
                          <th >Source</th>
                          <th >Description</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM dangertable";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['id'] ?> </td>
                              <td> <?php echo $row['type'] ?> </td>
                              <td> <?php echo $row['victime'] ?> </td>
                              <td> <?php echo $row['bourreau'] ?> </td>
                              <td> <?php echo $row['lieu'] ?> </td>
                              <td class="mr-5 ml-5"> <button class="btn btn-light btn-block text-capitalize"><a href="<?php echo $row['source'] ?>">Source</a></button></td></button></td>
                              <td> <?php echo $row['description'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                            </tr>
                    <?php } ?>

                      </tbody>
                    </table>                         
                  </div>






                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Messages reçus</h2>                     
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Message</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM messages";
                    $result_msg = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_msg)) { ?>
                            <tr>
                              <td> <?php echo $row['id'] ?> </td>
                              <td> <?php echo $row['contenu'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                              <td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>




                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Utilisateur enregistrés</h2>                     
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Nom</th>
                          <th >Mail</th>
                          <th >Fontion</th>
                          <th >Date d'inscription</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM utilisateurs";
                    $result_msg = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_msg)) { ?>
                            <tr>
                              <td> <?php echo $row['id_utilisateur'] ?> </td>
                              <td> <?php echo $row['nom'] ?> </td>
                              <td> <?php echo $row['mail'] ?> </td>
                              <td> <?php echo $row['fnc'] ?> </td>
                              <td> <?php echo $row['dateinscript'] ?> </td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>
             </div>



      <div class="container">
             <div class="table-responsive mt-5" >
                    <h2 class="text-center">Activités enregistrés</h2> 


                    
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th >Activité</th>
                          <th >Objet</th>
                          <th >Acteur (Utilisateur)</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM user_activite";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['id_user_activite'] ?></td>
                              <td> <?php echo $row['nom_activite'] ?> </td>
                              <td> <?php echo $row['objet'] ?> </td>
                              <td> <?php echo $row['nom_utilisateur'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Lieux ajoutés</h2>                     
                    <table class="table rounded table-info" id="maTable">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Nom du lieu</th>
                          <th >Pays</th>
                          <th >Ville</th>
                          <th >Lattitude</th>
                          <th >Longitude</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM lieux";
                    $result_lieux = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_lieux)) { ?>
                            <tr>
                              <td> <?php echo $row['id_lieu'] ?> </td>
                              <td> <?php echo $row['nom'] ?> </td>
                              <td> <?php echo $row['pays'] ?> </td>
                              <td> <?php echo $row['ville'] ?> </td>
                              <td> <?php echo $row['lat'] ?> </td>
                              <td> <?php echo $row['lng'] ?> </td>
                              
                            </tr>
                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



                    
                    <?php
                  }elseif($fnc!= 'Superviseur'){
                  ?>
                      
                    <!-- OPERATEUR -->

                  <div class="container">
                  <div class="col color2 mt-3 mb-5 rounded d-flex justify-content-center bg-dark">
                    <h1 style="color: #FFF;">Listes</h1>
                  </div>

                        <!-- alerte -->
                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Dangers enregistrés</h2>                     
                    <table class="table rounded table-info" id="maTable">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Danger</th>
                          <th >Victime</th>
                          <th >Bourreau</th>
                          <th >Lieu</th>
                          <th >Source</th>
                          <th >Description</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM dangertable";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['id'] ?> </td>
                              <td> <?php echo $row['type'] ?> </td>
                              <td> <?php echo $row['victime'] ?> </td>
                              <td> <?php echo $row['bourreau'] ?> </td>
                              <td> <?php echo $row['lieu'] ?> </td>
                              <td class="mr-5 ml-5"> <button class="btn btn-light btn-block text-capitalize"><a href="<?php echo $row['source'] ?>">Source</a></button></td>
                              <td> <?php echo $row['description'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                            </tr>
                    <?php } ?>

                      </tbody>
                    </table>                         
                  </div>



                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Messages reçus</h2>                     
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Message</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM messages";
                    $result_msg = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_msg)) { ?>
                            <tr>
                              <td> <?php echo $row['id'] ?> </td>
                              <td class="col-8"> <?php echo $row['contenu'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                              <td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Utilisateurs enregistrés</h2>                     
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Nom</th>
                          <th >Mail</th>
                          <th >Fontion</th>
                          <th >Date d'inscription</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM utilisateurs";
                    $result_msg = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_msg)) { ?>
                            <tr>
                              <td> <?php echo $row['id_utilisateur'] ?> </td>
                              <td> <?php echo $row['nom'] ?> </td>
                              <td> <?php echo $row['mail'] ?> </td>
                              <td> <?php echo $row['fnc'] ?> </td>
                              <td> <?php echo $row['dateinscript'] ?> </td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Activités enregistrés</h2> 


                    
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >Activité</th>
                          <th >Objet</th>
                          <th >Acteur (Utilisateur)</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM user_activite";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['nom_activite'] ?> </td>
                              <td> <?php echo $row['objet'] ?> </td>
                              <td> <?php echo $row['nom_utilisateur'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>
             </div>





                <?php
              } else {
                  ?> 
                <!-- SUPERVISEUR -->



            <div class="container">
                  <div class="col color2 mt-3 mb-5 rounded d-flex justify-content-center bg-dark">
                    <h1 style="color: #FFF;">Contenu</h1>
                  </div>

                        <!-- alerte -->
                  <div class="table-responsive " >
                    <h2 class="text-center">Dangers enregistrés</h2>                     
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >Danger</th>
                          <th >Victime</th>
                          <th >Bourreau</th>
                          <th >Lieu</th>
                          <th >Source</th>
                          <th >Description</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM dangertable";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['type'] ?> </td>
                              <td> <?php echo $row['victime'] ?> </td>
                              <td> <?php echo $row['bourreau'] ?> </td>
                              <td> <?php echo $row['lieu'] ?> </td>
                              <td class="mr-5 ml-5"> <button class="btn btn-light btn-block text-capitalize"><a href="<?php echo $row['source'] ?>">Source</a></button></td>
                              <td> <?php echo $row['description'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                            </tr>
                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Messages reçus</h2>                     
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Message</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM messages";
                    $result_msg = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_msg)) { ?>
                            <tr>
                              <td> <?php echo $row['id'] ?> </td>
                              <td> <?php echo $row['contenu'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                              <td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Utilisateurs enregistrés</h2>                     
                    <table class="table rounded table-info">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Nom</th>
                          <th >Mail</th>
                          <th >Fontion</th>
                          <th >Date d'inscription</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM utilisateurs";
                    $result_msg = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_msg)) { ?>
                            <tr>
                              <td> <?php echo $row['id_utilisateur'] ?> </td>
                              <td> <?php echo $row['nom'] ?> </td>
                              <td> <?php echo $row['mail'] ?> </td>
                              <td> <?php echo $row['fnc'] ?> </td>
                              <td> <?php echo $row['dateinscript'] ?> </td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Activités enregistrés</h2> 


                    
                    <table class="table rounded table-info" id="maTable">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Activité</th>
                          <th >Objet</th>
                          <th >Acteur (Utilisateur)</th>
                          <th >Date</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM user_activite";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['id_user_activite'] ?> </td>
                              <td> <?php echo $row['nom_activite'] ?> </td>
                              <td> <?php echo $row['objet'] ?> </td>
                              <td> <?php echo $row['nom_utilisateur'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>




                  <div class="table-responsive mt-5" >
                    <h2 class="text-center">Lieux ajoutés</h2>                     
                    <table class="table rounded table-info" id="maTable">
                      <thead>
                        <tr>
                          <th >ID</th>
                          <th >Nom du lieu</th>
                          <th >Pays</th>
                          <th >Ville</th>
                          <th >Lattitude</th>
                          <th >Longitude</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM lieux";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['id_lieu'] ?> </td>
                              <td> <?php echo $row['nom'] ?> </td>
                              <td> <?php echo $row['pays'] ?> </td>
                              <td> <?php echo $row['ville'] ?> </td>
                              <td> <?php echo $row['lat'] ?> </td>
                              <td> <?php echo $row['lng'] ?> </td>
                              
                            </tr>
                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>



             </div>



             <?php }?>




            </div>
          </div>
          <footer class="footer">
            <div class="container-fluid">
              <nav class="float-left">
                <ul>
                  <li>
                    <a href="">
                       DANGER VIEW ENGINE
                    </a>
                  </li>
                </ul>
              </nav>
              <div class="copyright float-right" >
                Copright
                &copy;
                <script>
                  document.write(new Date().getFullYear())
                </script>, 
              </div>
              <!-- your footer here -->
            </div>
          </footer>
        </div>
      </div>



      <script type="text/javascript">
        
        $(document).ready( function () {
           $('#maTable').DataTable();
        } );

      </script>
      <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
      <script
        src="https://code.jquery.com/jquery-3.5.1.min.js"
        integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    </body>

</html>




















