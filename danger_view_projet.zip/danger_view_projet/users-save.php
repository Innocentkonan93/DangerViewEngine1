<?php session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom']; 
  $fnc = $_SESSION['fnc'];
}else{
        echo '<script language="Javascript">';
        echo 'document.location.replace("./logout.php")'; // -->
        echo ' </script>';
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>Users</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  
  <link rel="stylesheet" type="text/css" href="styles.css">
  <!--     Fonts and icons     -->
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <!--bootstrap-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <!--Font awasome-->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="wrapper ">
 

 <!-- Administrateur sidebar -->
  <?php
          if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
          ?>

    <div class="sidebar" data-color="green" data-background-color="white">
    <!--Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag-->
    <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
        <img src="avatar.png">
      </a>
      <h3 href="" class="simple-text logo-normal">
        <?php echo "$nom"; ?>
      <h3>
      <h5 class="text-center"><?php echo "$fnc"; ?></h5>
    </div>
    <div class="sidebar-wrapper ">
        <center>
          <button class="nav-item active btn mt-3"><a href="page.php">Tableau de bord</a></button>
        </center>
        <ul class="p-2 m-2 rounded" id="sidebarLink">
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Enregistrement</h5>
          <li id="active"><a href="users-save.php">Ajouter un utilisateur</a></li>
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Gestion</h5>
          <li><a href="users_lists.php">Modifier un utilisateur</a></li>
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Affichage</h5>
          <li><a href="listes.php">Voir les listes</a></li>
    </div>
  </div>

    <!-- Operateur sidebar --> 
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
        <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <center>
          <button class="nav-item active btn mt-3">Tableau de bord</button>
        </center>
        <ul class="p-2 m-2 rounded" id="sidebarLink">
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-2 fa fa-plus-circle"></i>Enregistrement</h5>
          <li><a href="acc.php">Ajouter un danger</a></li>
          <li><a href="lieu.php">Ajouter un lieu</a></li>
          <h5 class="text-uppercase mt-4 text-center"><i class=" mr-4 fas fa-list-alt"></i>Listage</h5>
          <li><a href="register.php">Liste</a></li>
        </ul>
      </div>
    </div>




              <?php
            } else {
                ?> 


<!-- Superviseur sidebar -->


  <div class="sidebar" data-color="green" data-background-color="white">
      <div class="logo">
        <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Tableau de bord</p>
            </a>
          </li>

      </div>
    </div>
 <!-- your sidebar here -->




     <?php }?>
  
      <!-- Navbar -->
      <nav class="navbar navbar-light p-0 mb-0 " id="navbar">
        <a class="" href="#">
          <img src="danger.png" width="150" height="auto" class="d-inline-block align-top img-fluid" alt="logo" style="margin-left: 250px;">
        </a>

        <ul class="navbar mr-5" style="list-style: none; font-size: 25px;">
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-bell"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-envelope">
            
          </i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"> <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a> </li>
        </ul>

      </nav>
      <!-- End Navbar -->
      <div class="content"style="margin-left: 250px;">
        <div class="container-fluid" >
          <!-- your content here -->

          <div class="row justify-content-center" style="color: #000;">
            <div class="col-4 border border-danger bg-inverse bg-faded mt-5 rounded p-3">
              <h3 class="text-center mb-5">Enegistrer un utilisateur</h3>

                <?php
                  if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
                  ?>
          <!-- Administrateur -->
               <?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "dangerviewdb";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection
            if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
            }

            if(isset($_POST['inscription'])){
            $nom = $_POST['nom'];
            $mail = $_POST['mail'];
            $mdp = md5($_POST['mdp']);
            $fnc = $_POST['fnc'];
            $dateinscript = date("Y-m-d");

            $sql = "INSERT INTO utilisateurs (nom, mail, mdp, fnc, dateinscript)
            VALUES ('$nom', '$mail', '$mdp','$fnc','$dateinscript')";

            if (mysqli_query($conn, $sql)) {
              echo '

                <div class="alert alert-success alert-dismissible fade show" role="alert">
                  Enregistré avec succes !
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

              ';




            } else {
              echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }

            }

            mysqli_close($conn);

            ?>



              <form action="" method="POST" class="form-signin">
              <div class="form-label-group">
                <label for="inputNom">Nom & Prénom</label>
                <input type="text" name="nom" id="inputNom" class="form-control " placeholder="Nom & Prénom" autofocus required >
              </div>

              <div class="form-label-group">
                <label for="inputEmail">Adresse mail</label>
                <input type="text" name="mail" id="inputEmail" class="form-control" placeholder="Adresse mail" required>
              </div>

              <div class="form-label-group">
                <label for="inputPassword">Mot de passe</label>
                <input type="password" name="mdp" id="inputPassword" class="form-control" placeholder="Mot de passe" required > 
              </div>

              <div class="form-label-group mb-5">
                <label for="inputFonction">Fonction</label>
                <select name="fnc" class="form-control" id="inputFonction">
                  <option>--Définir une fonction--</option>
                  <option>Administrateur</option>
                  <option>Superviseur</option>
                  <option>Opérateur</option>
                </select>
              </div>

              <button name="inscription" class="btn btn-sm btn-success btn-block text-uppercase">
              Enregistrer 
              </button>

            </form>
            </div>

          </div>




          <!-- Content Row -->

          
    </div>


        <!--Fin administrateur-->


            
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
            <!-- Opérateur -->

            
              ?>

            <?php
          } else {
              ?> 


            <!--superviseur-->



      <!-- fin superviseurs -->

         <?php }?>




            </div>
          </div>
          <footer class="footer">
            <div class="container-fluid">
              <nav class="float-left" style="margin-left:250px;">
                <ul>
                  <li>
                    <a href="">
                       DANGER VIEW ENGINE
                    </a>
                  </li>
                </ul>
              </nav>
              <div class="copyright float-right" >
                Copright
                &copy;
                <script>
                  document.write(new Date().getFullYear())
                </script>, 
              </div>
              <!-- your footer here -->
            </div>
          </footer>
        </div>
      </div>

      <?php


      ?>

      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    </body>

</html>






















