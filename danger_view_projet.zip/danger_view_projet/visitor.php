<?php

$host ='localhost';
$user ='root';
$pass = '';
$db = 'dangerviewdb';

try
{
    $conn = new PDO("mysql:host=$host; dbname=$db", $user, $pass);
}
catch(PDOException $e)
{
    echo 'connexion échouée à la BD effectué..' .$e->getMessage();
}

$ip = $_SERVER['REMOTE_ADDR'];

$sql="SELECT ip FROM visiteurs WHERE ip='$ip'";
$Check=$conn->prepare($sql);
$Check->execute();
$CheckIp=$Check->rowCount();
if($CheckIp==0)
{
    $query="INSERT TO visiteurs(id,ip) VALUES(NULL, '$ip')";
    $insertIp=$conn->prepare($query);
    $insertIp->execute();
}
$number=$conn->prepare("SELECT ip FROM visiteurs");
$number->execute(); 
$visitor = $number ->rowCount();
echo $visitor;


?>