<?php session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom']; 
  $fnc = $_SESSION['fnc'];
}else{
        echo '<script language="Javascript">';
        echo 'document.location.replace("./logout.php")'; // -->
        echo ' </script>';
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>Users</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <!--bootstrap-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <!--Font awasome-->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="wrapper ">
 

 <!-- Administrateur sidebar -->
  <?php
          if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
          ?>

    <div class="sidebar" data-color="green" data-background-color="white">
    <!--Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag-->
    <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
        <img src="avatar.png">
      </a>
      <h3 href="" class="simple-text logo-normal">
        <?php echo "$nom"; ?>
      <h3>
      <h5 class="text-center"><?php echo "$fnc"; ?></h5>
    </div>
    <div class="sidebar-wrapper ">
      <ul class="nav">
        <li class="nav-item active  ">
          <a class="nav-link" href="#0">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
          </a>
        </li>

        <ul class="list-group mt-5 ">
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
        <!-- your sidebar here -->
      </ul>
    </div>
  </div>

    <!-- Operateur sidebar --> 
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
        <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <ul class="list-group mt-5 ">
          <h6 class="text-center" >Enregistrement</h6>
            <li class="list-group-item pl-2"> <a href="acc.php"><i class=" fa fa-plus-circle"></i>Enregistrer un danger</a> </li>
            <li class="list-group-item pl-2"> <a href="lieu.php"><i class=" fa fa-plus-circle"></i>Ajouter un lieu</a> </li>
          </ul>
          <ul class="list-group mt-4 ">
          <h6 class="text-center">Modification/Suppression</h6>
            <li class="list-group-item pl-2"> <a href="register.php"><i class="fas fa-tools"></i>Modifier un danger</a> </li>
          </ul>
          
          <!-- your sidebar here -->
      </div>
    </div>




              <?php
            } else {
                ?> 


<!-- Superviseur sidebar -->


  <div class="sidebar" data-color="green" data-background-color="white">
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Tableau de bord</p>
            </a>
          </li>
          <ul class="list-group mt-5 ">
            <li class="list-group-item">ssssssssss</li>
            
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>





     <?php }?>
  
      <!-- Navbar -->
      <nav class="navbar navbar-light p-0 bg-info mb-0 ">
        <a class="" href="#">
          <img src="danger.png" width="150" height="auto" class="d-inline-block align-top img-fluid" alt="logo" style="margin-left: 250px;">
        </a>

        <ul class="navbar mr-5" style="list-style: none; font-size: 25px;">
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-bell"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-envelope"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"> <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a> </li>
        </ul>

      </nav>
      <!-- End Navbar -->
      <div class="content"style="margin-left: 250px;">
        <div class="container-fluid" >
          <!-- your content here -->

            <?php
                  if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
                  ?>
            <!-- Administrateur -->


          <div class="row ml-4 ">
              


            <!-- Nombres d'inscription -->
            <div class="col mb-4 p-0">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Inscription Utilisateurs</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                      
                      <?php
                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";
                      
                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }

                      $query = "SELECT id FROM utilisateurs";

                      $query_run = mysqli_query($conn, $query);

                      $row = mysqli_num_rows($query_run);

                      echo '<h1> '.$row. '</h1><br>';
                      
                      
                      ?>
                      <h4>Inscris</h4>
                      </div>
                    </div>
                    <div class="col-auto mr-5">
                      <i class="fas fa-users fa-2x text-gray-300" style="font-size: 70px;"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!--  (-->
    

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dangers enregistrés</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                           
                          <?php
                          $servername = "localhost";
                          $username = "root";
                          $password = "";
                          $dbname = "dangerviewdb";
                          
                          // Create connection
                          $conn = mysqli_connect($servername, $username, $password, $dbname);
                          // Check connection
                          if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                          }

                          $query = "SELECT id FROM dangertable";

                          $query_run = mysqli_query($conn, $query);

                          $row = mysqli_num_rows($query_run);

                          echo '<h1> '.$row. '</h1><br>';
                          
                          
                          ?>
                          
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300" style="font-size: 70px;"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1 mB-3">Message reçus</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-gray-300 mt" style="font-size: 70px;"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div class="row mb-3 ml-5 mr-2">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Requests</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <!-- Content Row -->

          <div class="row">

            <!-- Area Chart -->
            <div class="col-xl-8 col-lg-7">
              <div class="card shadow ml-5">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Total Inscription</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Dropdown Header:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Another action</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                  </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                  </div>
                </div>
              </div>
            </div>

          <!-- Content Row -->
          </div class="col-xl-4 ml-5" >


          </div>
    </div>


        <!--Fin administrateur-->


            
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
            <!-- Opérateur -->

            <div class="col ">
              <div class="jumbotron color1 rounded-0 pt-0 ">
                  <div class="row">
                    <div class="col color2 mt-3 rounded d-flex justify-content-center bg-dark">
                      <h1 style="color: #FFF;">Contenu</h1>
                    </div>
                  </div>
                  <div class="container">
                    <div class="row justify-content-center align-items-center ">
                      <div class="col-6 card card-body mt-4 shadow bg-warning ">
                        <h2 class="mb-4">Ajouter une information</h2>

        <!-- Formulaire d'enregistrement infos -->

                      <?php

                          if (isset($_POST['savedanger'])) {?>
                            
                          <div class="alert alert-success alert-dismissible fade show" role="alert">
                            Enregistré avec succes !
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>

                      <?php }?>

                      <!-- alerte -->

                              

                      <form class="user" action="" method="POST">
                        <div class="form-group">
                          <label class="text-dark" for="formGroupExampleInput">Type de danger</label>
                          <?php
                                $options = array( 'Accident', 'Arnaque', 'Braquage', 'Crime', 'passionnel', 'Enlèvement', 'Incendie', 'Inondation', 'Intoxication', 'Suicide', 'Trouble', 'Publics', 'ViolViolence', 'conjugale' );
                                echo '<select class="form-control" name="type">';
                                foreach($options as $option){
                                  echo "<option value='$option'>$option </option>";
                                }
                                echo '</select>';
                              ?>
                        </div>
                        <div class="form-group">
                          <label class="text-dark" for="exampleFormControlSelect1">Victime</label>
                          <select class="form-control" name="victime" id="exampleFormControlSelect1">
                            <option>Homme</option>
                            <option>Femme</option>
                            <option>Enfant</option>
                            <option>Groupe de personnes</option>
                            <option>Nature</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <label class="text-dark" for="exampleFormControlSelect2">Bourreau</label>
                          <select class="form-control" name="bourreau" id="exampleFormControlSelect2" required>
                            <option>Homme</option>
                            <option>Femme</option>
                            <option>Enfant</option>
                            <option>Groupe de personnes</option>
                            <option>Nature</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <label class="text-dark for="formGroupExampleInput2">Lieu</label>
                          <input type="text" class="form-control" id="formGroupExampleInput2" name="lieu" placeholder="Ajouter un lieu">
                        </div>
                        <div class="form-group">
                          <label class="text-dark for="formGroupExampleInput2">Source</label>
                          <input type="text" class="form-control" id="formGroupExampleInput2" name="source" placeholder="Ajouter une source">
                        </div>
                        <div class="form-group">
                          <label class="text-dark" >Description</label>
                          <textarea rows="2" class="form-control" name="description" placeholder="Entrer une description du danger"></textarea>
                        </div>
                        <input type="submit" name="savedanger" class="btn btn-success mt-3" value="Enregistrer">
                      </form> 
            <!-- fin de formulaire  --> 
                      </div>
                  </div>  
                </div>
              </div>
          </div>




            <?php
          } else {
              ?> 


            <!--superviseur-->

<div class="row ml-4 ">
              <!-- Nombres d'inscription -->
              <div class="col mb-4 p-0">
                <div class="card border-left-primary shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Inscription Utilisateurs</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "dangerviewdb";
                        
                        // Create connection
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        // Check connection
                        if (!$conn) {
                          die("Connection failed: " . mysqli_connect_error());
                        }
  
                        $query = "SELECT id FROM utilisateurs";
  
                        $query_run = mysqli_query($conn, $query);
  
                        $row = mysqli_num_rows($query_run);
  
                        echo '<h1> '.$row. '</h1><br>';
                        
                        
                        ?>
                        <h4>Inscris</h4>
                        </div>
                      </div>
                      <div class="col-auto mr-5">
                        <i class="fas fa-users fa-2x text-gray-300" style="font-size: 70px;"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
  
              <!--  (-->
      
  
              <!-- Earnings (Monthly) Card Example -->
              <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dangers enregistrés</div>
                        <div class="row no-gutters align-items-center">
                          <div class="col-auto">
                             
                            <?php
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "dangerviewdb";
                            
                            // Create connection
                            $conn = mysqli_connect($servername, $username, $password, $dbname);
                            // Check connection
                            if (!$conn) {
                              die("Connection failed: " . mysqli_connect_error());
                            }
  
                            $query = "SELECT id FROM dangertable";
  
                            $query_run = mysqli_query($conn, $query);
  
                            $row = mysqli_num_rows($query_run);
  
                            echo '<h1> '.$row. '</h1><br>';
                            
                            
                            ?>
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300" style="font-size: 70px;"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
  
              <!-- Pending Requests Card Example -->
              <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1 mB-3">Message reçus</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><h1>0</h1></div>
                      </div>
                      <div class="col-auto">
                        <i class="fas fa-comments fa-2x text-gray-300 mt" style="font-size: 70px;"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

      <div class="col">
      
      <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1 mB-3"> Total visites</div>
                              <p>(IP)</p>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "dangerviewdb";
                            
                            // Create connection
                            $conn = mysqli_connect($servername, $username, $password, $dbname);
                            // Check connection
                            if (!$conn) {
                              die("Connection failed: " . mysqli_connect_error());
                            }
  
                            $query = "SELECT id FROM visiteurs";
  
                            $query_run = mysqli_query($conn, $query);
  
                            $row = mysqli_num_rows($query_run);
  
                            echo '<h1> '.$row. '</h1><br>';
                            
                            
                        ?>
                        </div>
                      </div>
                      <div class="col-auto">
                        <i class="fas fa-eye  text-gray-300 mt" style="font-size: 70px;"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

      </div>



      <!-- fin superviseurs -->

         <?php }?>




            </div>
          </div>
          <footer class="footer">
            <div class="container-fluid">
              <nav class="float-left" style="margin-left:250px;">
                <ul>
                  <li>
                    <a href="">
                       DANGER VIEW ENGINE
                    </a>
                  </li>
                </ul>
              </nav>
              <div class="copyright float-right" >
                Copright
                &copy;
                <script>
                  document.write(new Date().getFullYear())
                </script>, 
              </div>
              <!-- your footer here -->
            </div>
          </footer>
        </div>
      </div>

      <?php


      ?>

      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    </body>

</html>





<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dangerviewdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['savedanger'])){
$type = $_POST['type'];
$victime = $_POST['victime'];
$bourreau = ($_POST['bourreau']);
$lieu = $_POST['lieu'];
$source = $_POST['source'];
$description = $_POST['description'];

$sql = "INSERT INTO dangertable (type, victime, bourreau, lieu, source, description)
VALUES ('$type', '$victime', '$bourreau', '$lieu', '$source', '$description')";

if (mysqli_query($conn, $sql)) {
  echo "information enregistrée";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}


$query = "SELECT * FROM dangertype";

$result1 = mysqli_query($conn, $query);



mysqli_close($conn);

?>


















