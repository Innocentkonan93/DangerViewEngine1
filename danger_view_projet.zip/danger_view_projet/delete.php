<?php

      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "dangerviewdb";

      // création de la connexion

      $conn = mysqli_connect($servername, $username, $password, $dbname);

      //verification de la connexion

      if (!$conn) {
        die('Echec de la connexion :' .mysqli_connect_error());
      }



      if (isset($_GET['id'])) {
      	$id = $_GET['id'];

      	$query = "DELETE FROM lieux WHERE id_lieu= '$id'";
      	$result = mysqli_query($conn, $query);

      	if (!$result) {
      		die("Query failed");
      	}

      	header('Location: register.php');
      }


      if (isset($_GET['id'])) {
            $id = $_GET['id'];

            $query = "DELETE FROM utilisateurs WHERE id_utilisateur= '$id'";
            $result = mysqli_query($conn, $query);

            if (!$result) {
                  die("Query failed");
            }

            $_SESSION['message'] = "Supprimer avec succes";
            $_SESSION['message_type'] = "danger";

            header('Location: users_lists.php');

            
      }



      if (isset($_GET['id'])) {
            $id = $_GET['id'];

            $query = "DELETE FROM messages WHERE id= '$id'";
            $result = mysqli_query($conn, $query);

            if (!$result) {
                  die("Query failed");
            }

            $_SESSION['message'] = "Supprimer avec succes";
            $_SESSION['message_type'] = "danger";

            header('Location: messages.php');

            
      }

?>









 '

 <div class="alert alert-success alert-dismissible fade show" role="alert">
                  Enregistré avec succes !
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

 ';